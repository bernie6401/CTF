#!/bin/sh
/app/login_sys &
node /app/src/app.js
