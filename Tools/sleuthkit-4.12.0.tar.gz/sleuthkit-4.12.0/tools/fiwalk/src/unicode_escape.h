#ifndef UNICODE_ESCAPE_H
#define UNICODE_ESCAPE_H

#include <string>

std::string validateOrEscapeUTF8(std::string input);

#endif
