#!/bin/bash

exec 2>/dev/null

timeout 60 /home/perm_note/perm_note
