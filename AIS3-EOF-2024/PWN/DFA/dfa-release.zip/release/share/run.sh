#!/bin/sh

timeout 300 /home/dfa/dfa