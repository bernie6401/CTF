#!/bin/bash

cobc -x /root/cobolstrike.cbl -o /root/cobolstrike
