#!/bin/bash

exec 2>/dev/null

cd /home/Cobolstrike/archive
timeout 150 /home/Cobolstrike/cobolstrike
